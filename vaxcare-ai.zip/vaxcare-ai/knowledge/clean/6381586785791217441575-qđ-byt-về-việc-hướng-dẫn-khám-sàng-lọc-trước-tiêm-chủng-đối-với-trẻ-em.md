---
doc_id: 6381586785791217441575-qđ-byt-về-việc-hướng-dẫn-khám-sàng-lọc-trước-tiêm-chủng-đối-với-trẻ-em
source_file: 6381586785791217441575 QĐ-BYT về việc hướng dẫn khám sàng lọc trước tiêm chủng đối với trẻ em.pdf
---

BỘ Y TẾ
CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
Độc lập - Tự do - Hạnh phúc
Số: 1575/QĐ-BYT Hà Nội, ngày 27 tháng 3 năm 2023
QUYẾT ĐỊNH
VỀ VIỆC BAN HÀNH HƯỚNG DẪN KHÁM SÀNG LỌC TRƯỚC TIÊM CHỦNG ĐỐI VỚI TRẺ EM
BỘ TRƯỞNG BỘ Y TẾ
Căn cứ Luật Khám bệnh, chữa bệnh năm 2009;
Căn cứ Nghị định số 95/2022/NĐ-CP ngày 15 tháng 11 năm 2022 của Chính phủ quy định chức năng,
nhiệm vụ, quyền hạn và cơ cấu tổ chức của Bộ Y tế;
Theo đề nghị của Hội đồng chuyên môn xây dựng Hướng dẫn sửa đổi, bổ sung Hướng dẫn khám sàng lọc
trước tiêm chủng đối với trẻ em được thành lập theo Quyết định số 2319/QĐ-BYT ngày 26 tháng 8 năm
2022 của Bộ trưởng Bộ Y tế;
Theo đề nghị của Cục trưởng Cục Quản lý khám, chữa bệnh - Bộ Y tế.
QUYẾT ĐỊNH:
Điều 1. Ban hành kèm theo Quyết định này Hướng dẫn khám sàng lọc trước tiêm chủng đối với trẻ em.
Điều 2. Hướng dẫn khám sàng lọc trước tiêm chủng đối với trẻ em được áp dụng tại các cơ sở tiêm chủng,
cơ sở khám bệnh, chữa bệnh trong cả nước.
Điều 3. Sở Y tế tỉnh/thành phố có trách nhiệm chỉ đạo và thông báo danh sách các cơ sở khám chữa bệnh
tiếp nhận, khám sàng lọc và chỉ định tiêm chủng trên địa bàn đối với các trường hợp gửi chuyển từ tuyến
dưới.
Điều 4. Quyết định này có hiệu lực kể từ ngày ký ban hành.
- Bãi bỏ Quyết định số 2470/QĐ-BYT ngày 14 tháng 6 năm 2019 của Bộ trưởng Bộ Y tế về việc ban hành
Hướng dẫn khám sàng lọc trước tiêm chủng đối với trẻ em.
- Các cơ sở tiêm chủng tiếp tục thực hiện Bảng kiểm trước tiêm chủng vắc xin phòng COVID-19 đối với trẻ
em được ban hành kèm theo Quyết định số 5002/QĐ-BYT ngày 29/10/2021.
Điều 5. Các ông, bà: Chánh Văn phòng Bộ, Cục trưởng Cục Quản lý Khám, chữa bệnh, Chánh Thanh tra
Bộ, các Vụ trưởng, Cục trưởng của các Vụ/Cục thuộc Bộ Y tế; Giám đốc các cơ sở khám bệnh, chữa bệnh
trực thuộc Bộ Y tế; Giám đốc Sở Y tế các tỉnh, thành phố trực thuộc Trung ương; Thủ trưởng y tế các Bộ,
ngành; Thủ trưởng các đơn vị có liên quan chịu trách nhiệm thi hành Quyết định này./.
Nơi nhận:
- Như điều 5;
- Bộ trưởng Đào Hồng Lan (để báo cáo);
- Các Thứ trưởng (để biết)
- Lưu: VT; KCB.
KT. BỘ TRƯỞNG
THỨ TRƯỞNG
Trần Văn Thuấn
16:49 27/10/26 about:blank
about:blank 1/17
HƯỚNG DẪN
KHÁM SÀNG LỌC TRƯỚC TIÊM CHỦNG ĐỐI VỚI TRẺ EM
(Ban hành kèm theo Quyết định số 1575/QĐ-BYT ngày 27 tháng 3 năm 2023)
DANH SÁCH BAN BIÊN SOẠN
“HƯỚNG DẪN KHÁM SÀNG LỌC TRƯỚC TIÊM CHỦNG ĐỐI VỚI TRẺ EM”
Chỉ đạo biên soạn
GS.TS. Trần Văn Thuấn Thứ trưởng Bộ Y tế
Chủ biên
PGS.TS. Trần Minh Điển Giám đốc Bệnh viện Nhi Trung ương
Tham gia biên soạn
TS. Nguyễn Trọng Khoa Phó Cục trưởng Cục Quản lý Khám, chữa bệnh
PGS.TS. Dương Thị Hồng Phó Viện trưởng Viện Vệ sinh dịch tễ Trung ương
TS. Vương Ánh Dương Phó Cục trưởng, Phụ trách Phòng Nghiệp vụ- Thanh tra- Bảo vệ
sức khỏe cán bộ Cục Quản lý Khám, chữa bệnh - Bộ Y tế
TS. Cao Việt Tùng Phó Giám đốc Bệnh viện Nhi Trung ương
TS. Lê Minh Trác Giám đốc Trung tâm Chăm sóc và điều trị sơ sinh, Bệnh viện Phụ
Sản Trung ương
BSCKII. Lê Thị Hà Giám đốc Trung tâm Sơ sinh, Bệnh viện Nhi Trung ương
TS. Nguyễn Văn Lâm Giám đốc Trung tâm Bệnh nhiệt đới, Bệnh viện Nhi Trung ương
TS. Đỗ Thị Nhàn Trưởng phòng Phòng Điều trị HIV/AIDS, Cục HIV/AIDS
TS. Đặng Thị Thúy Trưởng khoa Nhi, Bệnh viện Bệnh Nhiệt đới Trung Ương
TS. Lê Kiến Ngãi Trưởng khoa Dự phòng & Kiểm soát nhiễm khuẩn, Bệnh viện Nhi
Trung ương
PGS.TS. Tạ Anh Tuấn Trưởng khoa Điều trị tích cực nội khoa, Bệnh viện Nhi Trung
ương
BSCKII. Nguyễn Kiến Mậu Trưởng khoa Sơ sinh, Bệnh viện Nhi đồng 1
BS.CKI. Vũ Tề Đăng Phó trưởng khoa Sơ sinh, Bệnh viện Từ Dũ
ThS. Nguyễn Thị Mỹ Hạnh Chuyên viên Phòng Quản lý tiêm chủng và an toàn sinh học, Cục
Y tế dự phòng
ThS. Nguyễn Mai Hương Chuyên viên chính Vụ Sức khỏe bà mẹ và Trẻ em
Thư ký biên soạn
PGS.TS. Tạ Anh Tuấn Trưởng khoa Điều trị tích cực nội khoa, Bệnh viện Nhi Trung
ương
TS. Đặng Thị Thanh Huyền Văn phòng Chương trình Tiêm chủng mở rộng Quốc gia, Viện Vệ
sinh dịch tễ Trung ương
ThS. Nguyễn Liên Hương Văn phòng Chương trình Tiêm chủng mở rộng Quốc gia, Viện Vệ
sinh dịch tễ Trung ương
ThS. Lê Kim Dung Chuyên viên chính, Phòng Nghiệp vụ - Thanh tra - BVSKCB, Cục
Quản lý Khám, chữa bệnh
16:49 27/10/26 about:blank
about:blank 2/17
ThS. Đỗ Thị Huyền Trang Cục Quản lý Khám, chữa bệnh
Ds. Đỗ Thị Ngát Chuyên viên, Phòng Nghiệp vụ - Thanh tra - BVSKCB, Cục Quản
lý Khám, chữa bệnh
BS. Trần Trung Thành Văn phòng Chương trình Tiêm chủng mở rộng Quốc gia, Viện Vệ
sinh dịch tễ Trung ương
I. MỤC ĐÍCH CỦA KHÁM SÀNG LỌC
Hướng dẫn này bao gồm các phần thăm khám sàng lọc trước tiêm chủng cho trẻ trên 1 tháng và trẻ sơ sinh
nhằm mục đích quyết định cho trẻ có chống chỉ định tiêm chủng, đủ tiêu chuẩn tiêm chủng, trẻ tạm hoãn
tiêm chủng tại cơ sở tiêm chủng và các trường hợp phải chuyển khám sàng lọc tại bệnh viện.
II. KHÁM SÀNG LỌC TRƯỚC TIÊM CHỦNG CHO TRẺ EM ĐỐI VỚI CƠ SỞ NGOÀI BỆNH
VIỆN
1. Khám sàng lọc trước tiêm chủng cho trẻ em từ 1 tháng tuổi trở lên
1.1. Các trường hợp chống chỉ định
a) Có tiền sử phản vệ độ III trở lên sau tiêm chủng vắc xin lần trước (có cùng thành phần).
b) Trường hợp có tiền sử lồng ruột: Chống chỉ định với vắc xin Rota.
c) Trường hợp mắc suy giảm miễn dịch bẩm sinh: Chống chỉ định với vắc xin OPV.
d) Các trường hợp chống chỉ định khác theo hướng dẫn của nhà sản xuất đối với từng loại vắc xin.
1.2. Các trường hợp tạm hoãn
a) Có tiền sử phản ứng phản vệ độ II sau tiêm chủng vắc xin lần trước (có cùng thành phần): chuyển khám
sàng lọc và tiêm chủng tại bệnh viện.
b) Có tình trạng suy chức năng các cơ quan (như suy hô hấp, suy tuần hoàn, suy tim, suy thận, suy gan, suy
giảm ý thức...). Tiêm chủng khi sức khỏe của trẻ ổn định.
c) Mắc các bệnh cấp tính, các bệnh nhiễm trùng. Tiêm chủng khi sức khỏe của trẻ ổn định.
d) Sốt ≥ 38°C hoặc hạ thân nhiệt ≤ 35,5°C (đo nhiệt độ tại nách). Tiêm chủng khi thân nhiệt của trẻ ổn định.
e) Suy giảm miễn dịch: Trẻ nghi ngờ mắc hoặc mắc suy giảm miễn dịch bẩm sinh chưa xác định được mức
độ hoặc mắc suy giảm miễn dịch thể nặng: tạm hoãn tiêm chủng các vắc xin sống giảm độc lực và chuyển
khám sàng lọc tại bệnh viện. Tiêm chủng khi trẻ được chẩn đoán suy giảm miễn dịch không thuộc thể nặng,
ngoại trừ vắc xin bại liệt uống (OPV) (Phụ lục VII).
g) Trẻ mới dùng các sản phẩm globulin miễn dịch trong vòng 3 tháng (trừ kháng huyết thanh viêm gan B):
tạm hoãn tiêm chủng vắc xin sống giảm độc lực. Tiêm chủng cho trẻ khi đủ 3 tháng tính từ ngày cuối cùng
sử dụng sản phẩm.
h) Trẻ đang điều trị hoặc mới kết thúc đợt điều trị corticoid toàn thân (uống/ tiêm) với liều cao (tương
đương prednison ≥ 2 mg/kg/ngày), hóa trị (thuốc alkyl hóa, chất chống chuyển hóa, chất ức chế TNF-α, chất
ức chế IL-1 hoặc các kháng thể đơn dòng khác nhằm vào tế bào miễn dịch...), xạ trị trong vòng 14 ngày:
tạm hoãn tiêm chủng vắc xin sống giảm độc lực. Tiêm chủng cho trẻ sau khi kết thúc điều trị corticoid, hóa
trị và xạ trị 14 ngày.
16:49 27/10/26 about:blank
about:blank 3/17
i) Trẻ có cân nặng dưới 2000g: chuyển khám sàng lọc và tiêm chủng tại bệnh viện. Khi cân nặng trẻ từ
2000g trở lên thực hiện khám sàng lọc và tiêm chủng tại các cơ sở tiêm chủng ngoài bệnh viện.
k) Có tiền sử phản ứng tăng dần sau các lần tiêm chủng trước của cùng loại vắc xin (ví dụ: lần đầu không
sưng tấy, lần sau viêm sưng tấy lan tỏa tại vị trí tiêm...): chuyển khám sàng lọc và tiêm chủng tại bệnh viện.
l) Mắc các bệnh bẩm sinh hoặc bệnh mạn tính ở tim, phổi, hệ thống tiêu hóa, tiết niệu, máu, ung thư chưa ổn
định: chuyển khám sàng lọc tại bệnh viện. Tiêm chủng khi tình trạng bệnh của trẻ ổn định.
m) Các trường hợp tạm hoãn tiêm chủng khác theo hướng dẫn của nhà sản xuất đối với từng loại vắc xin.
2. Khám sàng lọc trước tiêm chủng cho trẻ dưới 1 tháng tuổi
Giai đoạn trẻ dưới 1 tháng tuổi khi thăm khám sàng lọc, cần chú ý đến tuần tuổi thai khi đẻ, tuổi thai hiệu
chỉnh, cân nặng, các chức năng cơ quan, bệnh lý cấp tính, các nghi ngờ bệnh suy giảm miễn dịch, phơi
nhiễm HIV... Một số các tình huống chống chỉ định, tạm hoãn cụ thể như sau:
2.1. Các trường hợp chống chỉ định
Các trường hợp chống chỉ định theo hướng dẫn của nhà sản xuất đối với từng loại vắc xin.
2.2. Các trường hợp tạm hoãn
a) Có tình trạng suy chức năng các cơ quan (như suy hô hấp, suy tuần hoàn, suy tim, suy thận, suy gan, suy
giảm ý thức...). Tiêm chủng khi sức khỏe của trẻ ổn định.
b) Mắc các bệnh cấp tính, các bệnh nhiễm trùng. Tiêm chủng khi sức khỏe của trẻ ổn định.
c) Sốt ≥ 38°C hoặc hạ thân nhiệt ≤ 35,5°C (đo nhiệt độ tại nách). Tiêm chủng khi thân nhiệt của trẻ ổn định.
d) Trẻ có cân nặng < 2000g: Chuyển khám sàng lọc, tiêm chủng tại bệnh viện.
đ) Nghi ngờ mắc hoặc mắc suy giảm miễn dịch bẩm sinh chưa xác định được mức độ hoặc mắc suy giảm
miễn dịch thể nặng: tạm hoãn tiêm chủng vắc xin phòng lao (BCG) và chuyển khám sàng lọc tại bệnh viện.
Tiêm chủng khi trẻ suy giảm miễn dịch không thuộc thể nặng. Chỉ định vắc xin bại liệt bất hoạt dạng tiêm
(IPV) thay thế vắc xin bại liệt sống giảm độc lực dạng uống (OPV). Xem thêm phụ lục VII về chỉ định,
chống chỉ định, tạm hoãn tiêm chủng với trẻ suy giảm miễn dịch bẩm sinh.
e) Trẻ sinh non có tuổi thai < 34 tuần tạm hoãn tiêm vắc xin phòng lao (BCG). Tiêm chủng khi trẻ đủ 34
tuần tuổi (tuổi thai hiệu chỉnh).
g) Trẻ sinh non có tuổi thai < 34 tuần: Nếu mẹ có HBsAg (-) tạm hoãn tiêm vắc xin viêm gan B sơ sinh,
tiêm chủng khi trẻ đủ 34 tuần tuổi (tuổi thai hiệu chỉnh). Nếu mẹ có HBsAg (+) hoặc mẹ không xét nghiệm
chuyển khám sàng lọc và tiêm chủng tại bệnh viện.
h) Trẻ mới dùng các sản phẩm globulin miễn dịch trong tuổi sơ sinh (trừ kháng huyết thanh viêm gan B):
tạm hoãn tiêm chủng vắc xin sống giảm độc lực. Tiêm chủng cho trẻ khi đủ 3 tháng tính từ ngày cuối cùng
sử dụng sản phẩm.
i) Mắc các bệnh bẩm sinh hoặc bệnh mạn tính ở tim, phổi, hệ thống tiêu hóa, tiết niệu, máu, thần kinh, ung
thư chưa ổn định: chuyển khám sàng lọc, tiêm chủng tại bệnh viện.
k) Các trường hợp tạm hoãn tiêm chủng khác theo hướng dẫn của nhà sản xuất đối với từng loại vắc xin.
3. Một số lưu ý khi khám sàng lọc trước tiêm chủng cho trẻ em đối với cơ sở ngoài bệnh viện
16:49 27/10/26 about:blank
about:blank 4/17
3.1. Trẻ phơi nhiễm với HIV, trẻ nhiễm HIV
Cơ sở quản lý, điều trị HIV/AIDS cần phối hợp đưa ra các thông số cơ bản (trẻ phơi nhiễm với HIV, trẻ
nhiễm HIV, biểu hiện lâm sàng, tình trạng miễn dịch...) để cơ sở tiêm chủng sàng lọc và ra quyết định tiêm
chủng cho trẻ. Đối với các vắc xin không phải là vắc xin sống giảm độc lực, chỉ định tiêm như trẻ bình
thường. Chống chỉ định vắc xin sống giảm độc lực với trẻ phơi nhiễm với HIV, trẻ nhiễm HIV tương tự trẻ
không nhiễm HIV (Chi tiết xem tại phụ lục IX).
Cần lưu ý một số tình huống chỉ định, tạm hoãn, thận trọng với vắc xin sống giảm độc lực cho trẻ phơi
nhiễm với HIV, trẻ nhiễm HIV như sau:
a) Phơi nhiễm với HIV nhưng chưa có dấu hiệu lâm sàng: Chỉ định tiêm chủng.
b) Có triệu chứng lâm sàng nghi ngờ nhiễm HIV: Tạm hoãn tiêm chủng cho đến khi khẳng định tình trạng
nhiễm HIV.
c) Được chẩn đoán xác định nhiễm HIV: cần phân loại mức độ miễn dịch ở trẻ nhiễm HIV, sau đó xác định
các tình huống có chống chỉ định, tạm hoãn/thận trọng tiêm chủng một số loại vắc xin sống giảm độc lực
(xem phụ lục IX).
Lưu ý theo dõi trẻ sau tiêm vắc xin BCG để phát hiện phản ứng sau tiêm vắc xin BCG như loét vị trí tiêm,
viêm hạch, bệnh BCG lan toả (suy mòn, gan lách hạch to).
3.2. Các trường hợp tạm hoãn tiêm chủng ở cơ sở ngoài bệnh viện cần chuyển khám sàng lọc tại bệnh
viện
a) Trẻ mắc suy giảm miễn dịch nếu tiêm chủng vắc xin sống giảm độc lực:
- Trẻ nghi ngờ mắc hoặc mắc suy giảm miễn dịch bẩm sinh chưa xác định được mức độ hoặc đã được chẩn
đoán suy giảm miễn dịch thể nặng cần khám tại bệnh viện có chuyên khoa miễn dịch để chẩn đoán xác định
bệnh hoặc thay đổi mức độ bệnh.
- Trẻ có biểu hiện lâm sàng nghi nhiễm hoặc xác định nhiễm HIV: Để chẩn đoán xác định và mức độ suy
giảm miễn dịch.
b) Trẻ có cân nặng dưới 2000g.
c) Trẻ có tiền sử phản ứng tăng dần sau các lần tiêm chủng trước của cùng loại vắc xin.
d) Trẻ có tiền sử phản ứng phản vệ độ II sau tiêm chủng vắc xin lần trước (có cùng thành phần)
đ) Trẻ mắc các bệnh bẩm sinh hoặc bệnh mạn tính ở tim, phổi, hệ thống tiêu hóa, tiết niệu, máu, thần kinh,
ung thư chưa ổn định.
e) Trẻ có tiền sử phản ứng với thuốc, sữa, thức ăn hoặc các loại dị nguyên khác.
III. KHÁM SÀNG LỌC TRƯỚC TIÊM CHỦNG CHO TRẺ EM TẠI BỆNH VIỆN
Khám sàng lọc tại bệnh viện được thực hiện cho các trường hợp chuyển đến từ cơ sở tiêm chủng ngoài bệnh
viện (phần II, mục 3.2) và các trẻ đang điều trị tại bệnh viện như nhóm trẻ sơ sinh, trẻ suy giảm miễn dịch,
trẻ bệnh mạn tính ổn định, bệnh lý cấp tính trước khi ra viện...
1. Khám sàng lọc trước tiêm chủng cho trẻ em từ 1 tháng tuổi trở lên
1.1. Các trường hợp chống chỉ định
16:49 27/10/26 about:blank
about:blank 5/17
a) Có tiền sử phản vệ độ III trở lên sau tiêm chủng vắc xin lần trước (có cùng thành phần).
b) Trường hợp có tiền sử lồng ruột: Chống chỉ định với vắc xin Rota.
c) Trường hợp mắc suy giảm miễn dịch bẩm sinh: Chống chỉ định với vắc xin OPV.
d) Các trường hợp chống chỉ định khác theo hướng dẫn của nhà sản xuất đối với từng loại vắc xin.
1.2. Các trường hợp tạm hoãn
a) Trẻ có tình trạng bệnh lý cấp cứu. Tiêm chủng khi sức khỏe của trẻ ổn định.
b) Mắc các bệnh cấp tính, các bệnh nhiễm trùng. Tiêm chủng khi sức khỏe của trẻ ổn định.
c) Sốt ≥ 38°C hoặc hạ thân nhiệt ≤ 35,5°C (đo nhiệt độ tại nách). Tiêm chủng khi thân nhiệt của trẻ ổn định.
d) Suy giảm miễn dịch: Trẻ nghi ngờ mắc hoặc mắc suy giảm miễn dịch bẩm sinh chưa xác định được mức
độ; mắc suy giảm miễn dịch thể nặng: tạm hoãn tiêm chủng các vắc xin sống giảm độc lực. Tiêm chủng khi
trẻ được chẩn đoán suy giảm miễn dịch không thuộc thể nặng và trước khi ra viện. Trẻ mắc suy giảm miễn
dịch bẩm sinh chỉ định vắc xin bại liệt bất hoạt dạng tiêm (IPV) thay thế vắc xin bại liệt dạng uống (OPV).
Xem thêm phụ lục VII về chỉ định, chống chỉ định, tạm hoãn tiêm chủng với trẻ suy giảm miễn dịch bẩm
sinh.
đ) Trẻ mới dùng các sản phẩm globulin miễn dịch trong vòng 3 tháng (trừ kháng huyết thanh viêm gan B):
Tạm hoãn tiêm chủng vắc xin sống giảm độc lực. Tiêm chủng cho trẻ khi đủ 3 tháng tính từ ngày cuối cùng
sử dụng sản phẩm.
e) Trẻ đang điều trị hoặc mới kết thúc đợt điều trị corticoid (uống/tiêm) với liều cao (tương đương prednison
≥ 2 mg/kg/ngày), hóa trị (thuốc alkyl hóa, chất chống chuyển hóa, chất ức chế TNF-α, chất ức chế IL-1 hoặc
các kháng thể đơn dòng khác nhằm vào tế bào miễn dịch), xạ trị trong vòng 14 ngày: tạm hoãn tiêm chủng
vắc xin sống giảm độc lực. Tiêm chủng cho trẻ sau khi kết thúc điều trị corticoid, hóa trị và xạ trị 14 ngày.
g) Trẻ mắc các bệnh bẩm sinh hoặc bệnh mạn tính ở tim, phổi, hệ thống tiêu hóa, tiết niệu, thần kinh, máu,
ung thư chưa ổn định. Tiêm chủng khi trẻ không ở trong tình trạng cấp tính, không có chỉ định can thiệp
điều trị cấp cứu và trước khi ra viện.
h) Các trường hợp tạm hoãn tiêm chủng khác theo hướng dẫn của nhà sản xuất đối với từng loại vắc xin.
2. Khám sàng lọc trước tiêm chủng cho trẻ dưới 1 tháng tuổi
Khám sàng lọc cho trẻ dưới 1 tháng tuổi tại bệnh viện được thực hiện cho trẻ đẻ ra tại bệnh viện và từ cơ sở
tiêm chủng ngoài bệnh viện gửi đến. Một số các lưu ý về chống chỉ định, tạm hoãn tiêm chủng cho trẻ dưới
1 tháng tuổi trong khám sàng lọc tại bệnh viện như sau:
2.1. Các trường hợp chống chỉ định
Các trường hợp chống chỉ định theo hướng dẫn của nhà sản xuất đối với từng loại vắc xin.
2.2. Các trường hợp tạm hoãn
a) Trẻ có chỉ định cấp cứu. Tiêm chủng khi sức khỏe của trẻ ổn định.
b) Trẻ sốt ≥ 38°C hoặc hạ thân nhiệt ≤ 35,5°C (đo nhiệt độ tại nách). Tiêm chủng khi thân nhiệt của trẻ ổn
định.
c) Trẻ có tuổi thai < 28 tuần. Tiêm chủng vắc xin viêm gan B khi trẻ đủ 28 tuần tuổi (tuổi thai hiệu chỉnh).
16:49 27/10/26 about:blank
about:blank 6/17
d) Trẻ có tuổi thai < 34 tuần tạm hoãn tiêm vắc xin phòng lao (BCG). Tiêm chủng khi trẻ đủ 34 tuần tuổi
(tuổi thai hiệu chỉnh).
e) Suy giảm miễn dịch: Nghi ngờ mắc hoặc mắc suy giảm miễn dịch bẩm sinh chưa xác định được mức độ;
mắc suy giảm miễn dịch thể nặng: Tạm hoãn tiêm chủng vắc xin phòng lao (BCG). Chuyển khám sàng lọc
tại các cơ sở khám chữa bệnh có chuyên khoa miễn dịch để xác định mức độ bệnh suy giảm miễn dịch.
Tiêm chủng khi trẻ suy giảm miễn dịch không thuộc thể nặng. Xem phụ lục VII về chống chỉ định, tạm
hoãn tiêm chủng với trẻ suy giảm miễn dịch bẩm sinh.
g) Trẻ mắc các bệnh bẩm sinh hoặc bệnh mạn tính ở tim, phổi, hệ thống tiêu hóa, tiết niệu, thần kinh, máu,
ung thư bẩm sinh chưa ổn định. Tiêm chủng khi trẻ không ở trong tình trạng cấp tính, không có chỉ định can
thiệp điều trị cấp cứu và trước khi ra viện.
h) Các trường hợp tạm hoãn tiêm chủng khác theo hướng dẫn của nhà sản xuất đối với từng loại vắc xin.
3. Một số lưu ý khi khám sàng lọc trước tiêm chủng tại bệnh viện
Thực hiện khám sàng lọc, tiêm chủng cho trẻ theo lịch và trước khi ra viện đối với những trường hợp không
thuộc diện chống chỉ định, tạm hoãn tiêm chủng tại bệnh viện. Tạm hoãn tiêm chủng với các trường hợp trẻ
phơi nhiễm với HIV và trẻ nhiễm HIV: chi tiết xem tại phần II, mục 3.1.
Một số các lưu ý khác khi thăm khám sàng lọc tại bệnh viện như sau:
3.1. Trẻ có vàng da: Tạm hoãn tiêm chủng với trường hợp vàng da mức độ nặng có chỉ định điều trị.
3.2. Trẻ đẻ non hoặc nhẹ cân so với tuổi
a) Thực hiện tiêm chủng vắc xin phòng lao (BCG) đối với trẻ sinh non khi trẻ có tuổi thai từ 34 tuần (tuổi
thai hiệu chỉnh).
b) Thực hiện tiêm chủng vắc xin Viêm gan B đối với trẻ sinh non khi trẻ có tuổi thai từ 28 tuần (tuổi thai
hiệu chỉnh).
c) Thực hiện tiêm chủng các vắc xin theo lịch với trẻ nhẹ cân (so với tuổi).
3.3. Trẻ đang điều trị kháng sinh: Khám, đánh giá tình trạng bệnh lý, nếu trẻ không có chống chỉ định hoặc
tạm hoãn. Thực hiện tiêm chủng cho trẻ theo lịch.
3.4. Trẻ thiếu yếu tố đông máu: truyền yếu tố đông máu bị thiếu, đảm bảo ổn định tình trạng đông máu
trước khi tiêm chủng.
IV. TỔ CHỨC THỰC HIỆN
1. Đối với cơ sở tiêm chủng ngoài bệnh viện
a) Người thực hiện
- Bác sĩ, y sĩ: trực tiếp thăm khám cho trẻ và ghi các thông tin của trẻ, trực tiếp đo và ghi kết quả nhiệt độ
của trẻ khi không có điều dưỡng viên, hộ sinh viên. Cán bộ y tế khám sàng lọc trước tiêm chủng phải được
tập huấn chuyên môn về tiêm chủng theo quy định tại Nghị định số 155/2018/NĐ-CP ngày 12 tháng 11 năm
2018.
- Điều dưỡng viên, hộ sinh viên: Ghi các thông tin của trẻ, trực tiếp cân trẻ, đo và ghi kết quả nhiệt độ của
trẻ.
b) Phương tiện
16:49 27/10/26 about:blank
about:blank 7/17
- Nhiệt kế, ống nghe.
- Bảng kiểm trước tiêm chủng cho đối tượng từ 1 tháng tuổi trở lên (phụ lục I)
- Bảng kiểm trước tiêm chủng cho trẻ sơ sinh (phụ lục II)
c) Các bước thực hiện khám sàng lọc trước tiêm chủng
Các bước thực hiện và điền theo bảng kiểm trước tiêm chủng bao gồm:
- Hỏi tiền sử và các thông tin có liên quan
- Đánh giá tình trạng sức khỏe hiện tại
- Kết luận
+ Đủ điều kiện tiêm chủng
+ Chống chỉ định tiêm chủng
+ Tạm hoãn tiêm chủng, chuyển khám sàng lọc và tiêm chủng tại bệnh viện (nếu cần thiết).
d) Ghi chép việc khám sàng lọc và lưu bảng kiểm
Toàn bộ nội dung khám sàng lọc được ghi theo bảng kiểm bao gồm kết quả khám chuyên khoa, lưu tại các
điểm tiêm chủng và trên Hệ thống Quản lý thông tin tiêm chủng Quốc gia. Lưu bảng kiểm 15 ngày.
e) Gửi chuyển các trường hợp tạm hoãn cần đánh giá tình trạng sức khỏe tại cơ sở khám chữa bệnh tuyến
trên:
+ Điền giấy chuyển tuyến khám bệnh, chữa bệnh theo Mẫu số 6 ban hành tại Nghị định số 146/2018/NĐ-CP
ngày 17/10/2018.
+ Ghi lý do chuyển tuyến khám kiểm tra tình trạng sức khỏe để chỉ định tiêm chủng tại phụ lục số 1 và 2
ban hành tại Hướng dẫn này.
+ Tư vấn cho phụ huynh/người chăm sóc đưa trẻ tới cơ sở khám chữa bệnh tuyến trên để được khám sàng
lọc.
+ Tiếp nhận và tiêm chủng đối với các trường hợp đã được kiểm tra đánh giá tình trạng sức khỏe bởi cơ sở
khám chữa bệnh tuyến trên và kết luận đủ điều kiện sức khỏe để tiêm chủng.
2. Đối với cơ sở tiêm chủng tại bệnh viện
a) Người thực hiện
- Bác sĩ, y sĩ khám sàng lọc trước tiêm chủng: khám, đánh giá, phối hợp với các thầy thuốc chuyên khoa
(nếu cần), đưa ra nhận xét và kết luận về chỉ định tiêm chủng cho trẻ.
- Bác sĩ chuyên khoa: khám, đánh giá tình trạng bệnh lý của trẻ theo chuyên khoa; phối hợp với bác sĩ tư
vấn tiêm chủng để đưa ra kết luận về chỉ định tiêm chủng cho trẻ.
- Cán bộ y tế có liên quan đến tư vấn, tiêm chủng vắc xin và theo dõi phản ứng sau tiêm chủng.
b) Phương tiện
- Có đủ phương tiện để thực hiện việc khám sàng lọc và khám chuyên khoa.
16:49 27/10/26 about:blank
about:blank 8/17
- Phiếu khám sàng lọc trước tiêm chủng cho đối tượng từ 1 tháng tuổi trở lên (phụ lục III) và phiếu khám
sàng lọc trước tiêm chủng cho trẻ sơ sinh (phụ lục IV).
c) Các bước thực hiện
- Bác sĩ tư vấn, khám sàng lọc tiêm chủng: khám đánh giá toàn diện các điều kiện tiêm chủng cho trẻ; tham
vấn thầy thuốc chuyên khoa về tình trạng bệnh lý theo chuyên khoa (nếu cần). Đưa ra kết luận về điều kiện
tiêm chủng cho trẻ.
- Bác sĩ chuyên khoa: khi được yêu cầu, đánh giá đầy đủ về tình trạng bệnh lý theo chuyên khoa cần tham
vấn; đưa ra nhận xét, đề nghị liên quan đến tiêm chủng về tình trạng bệnh lý của trẻ. Phối hợp với cán bộ
tiêm chủng tại bệnh viện thực hiện tiêm chủng và theo dõi sau tiêm chủng cho trẻ khi cần.
d) Ghi chép việc khám sàng lọc và lưu hồ sơ
- Thực hiện việc ghi chép, lưu giữ cơ sở dữ liệu tiêm chủng theo quy định hiện hành và các quy định về ghi
chép sổ khám bệnh, hồ sơ bệnh án như đối với trẻ đến khám, điều trị ngoại trú, nội trú tại bệnh viện.
- Trường hợp có hồ sơ bệnh án tại bệnh viện: toàn bộ nội dung khám sàng lọc trong bảng kiểm và y lệnh chỉ
định tiêm phải được ghi trong hồ sơ bệnh án hoặc phiếu khám sàng lọc trước tiêm chủng được lưu cùng hồ
sơ bệnh án theo quy định.
- Trường hợp không có hồ sơ bệnh án tại bệnh viện: Phiếu khám sàng lọc trước tiêm chủng được lưu tại
điểm tiêm chủng và trên Hệ thống Quản lý thông tin tiêm chủng quốc gia. Lưu bảng kiểm 15 ngày.
e) Đánh giá tình trạng sức khỏe, tiêm chủng đối với các trường hợp gửi chuyển từ tuyến dưới và bệnh nhi
trước khi ra viện:
- Tiếp nhận và tổ chức thực hiện khám sàng lọc, chỉ định, tiêm chủng đối với các trường hợp gửi chuyển từ
tuyến dưới và bệnh nhi đang điều trị tại cơ sở trước khi ra viện.
- Đối với các trường hợp trẻ mắc suy giảm miễn dịch bẩm sinh hoặc xác định nhiễm HIV, cần ghi đầy đủ
thông tin khám bệnh, tình trạng miễn dịch kèm theo kết quả xét nghiệm miễn dịch (nếu có) và chỉ
định/chống chỉ định/tạm hoãn đối với các vắc xin sống, giảm độc lực.
- Thông báo cho cơ sở tiêm chủng ngoài bệnh viện, tư vấn, hướng dẫn cho cha mẹ/người chăm sóc trẻ về
việc tiêm chủng các mũi tiếp theo.
PHỤ LỤC I
(Ban hành kèm theo Quyết định số 1575/QĐ-BYT ngày 27 tháng 03 năm 2023)
TTKSBT/TTYT/TYT/PK/NHS
……………………………
CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
Độc lập - Tự do - Hạnh phúc
BẢNG KIỂM TRƯỚC TIÊM CHỦNG ĐỐI VỚI ĐỐI TƯỢNG TỪ 1 THÁNG TUỔI TRỞ LÊN TẠI
CÁC CƠ SỞ TIÊM CHỦNG NGOÀI BỆNH VIỆN
Họ và tên trẻ: ………………………………………………………………………..Nam □ Nữ □
Tuổi:........................................ sinh ngày ……………tháng ………….năm .....................
Địa chỉ: .......................................................................................................................
Họ tên bố/mẹ: ……………………………………………. Điện thoại:....................................
16:49 27/10/26 about:blank
about:blank 9/17
Cân năng: kg Thân nhiệt: , °C
I. Khám sàng lọc:
1. Phản vệ độ III trở lên sau lần tiêm chủng trước (vắc xin có cùng thành phần) Không □ Có □
2. Phản vệ độ II sau lần tiêm chủng trước (vắc xin có cùng thành phần) Không □ Có □
3. Đang mắc bệnh cấp tính hoặc bệnh mạn tính tiến triển* Không □ Có □
4. Sốt/Hạ thân nhiệt (sốt: nhiệt độ ≥ 38°C; Hạ thân nhiệt: nhiệt độ ≤ 35,5°C) Không □ Có □
5. Suy giảm miễn dịch chưa xác định mức độ hoặc mức độ nặng, có biểu hiện lâm
sàng nghi nhiễm HIV Không □ Có □
6. Đang hoặc mới kết thúc đợt điều trị corticoid liều cao (tương đương prednison
>2mg/kg/ngày), hóa trị, xạ trị, gammaglobulin** Không □ Có □
7. Phản ứng tăng dần sau các lần tiêm chủng trước (vắc xin có cùng thành phần)
8. Nghe tim bất thường Không □ Có □
9. Nhịp thở, nghe phổi bất thường Không □ Có □
10. Tri giác bất thường (li bì hoặc kích thích) Không □ Có □
11. Cân nặng < 2000g Không □ Có □
12. Các chống chỉ định khác, nếu có ghi rõ:
…………………………………………………………………………………….
Không □ Có □
*: Không hoãn tiêm vắc xin đối với trẻ có bệnh nhẹ (ho, sổ mũi, tiêu chảy mức độ nhẹ... và không sốt), bú
tốt, ăn tốt
**: Trừ kháng huyết thanh viêm gan B. Tiêu chuẩn này chỉ áp dụng với vắc xin sống giảm độc lực.
II. Kết luận:
- Đủ điều kiện tiêm chủng ngay (Tất cả đều KHÔNG có điểm bất thường) □
Loại vắc xin tiêm chủng lần này:………………………………………………………………
- Chống chỉ định tiêm chủng (Khi CÓ điểm bất thường tại mục 1,12) □
- Tạm hoãn tiêm chủng (Khi CÓ bất kỳ một điểm bất thường tại các mục từ 2 đến 11) □
Đề nghị khám sàng lọc tại bệnh viện: Không □ Có □
+ Lý do: …………………………………………………………………………………………………….
…....giờ …….phút, ngày....tháng....năm…..
Người thực hiện sàng lọc
(ký, ghi rõ họ và tên)
PHỤ LỤC II
(Ban hành kèm theo Quyết định số 1575/QĐ-BYT ngày 27 tháng 03 năm 2023)
TTKSBT/TTYT/TYT/PK/NHS
……………………………
CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
Độc lập - Tự do - Hạnh phúc
16:49 27/10/26 about:blank
about:blank 10/17
BẢNG KIỂM TRƯỚC TIÊM CHỦNG ĐỐI VỚI TRẺ DƯỚI 1 THÁNG TUỔI TẠI CÁC CƠ SỞ
TIÊM CHỦNG NGOÀI BỆNH VIỆN
Họ và tên trẻ:…………………………………………………………………………….Nam □ Nữ □
Sinh: ……….. giờ …….. ngày…….. tháng …… năm ……… Tuổi thai khi sinh: ................
Địa chỉ: .......................................................................................................................
Họ tên bố/mẹ: …………………………………………….. Điện thoại: ..................................
Cân nặng: g Thân nhiệt: , °C
Mẹ đã xét nghiệm HbsAg: Không □ Có □ Kết quả: Dương tính □ Âm tính □
I. Khám sàng lọc:
1. Đang mắc bệnh cấp tính hoặc bệnh mạn tính tiến triển*
2. Sốt/Hạ thân nhiệt (Sốt: nhiệt độ ≥ 38°C; Hạ thân nhiệt: nhiệt độ ≤ 35,5°C) Không □ Có □
3. Cân nặng < 2000 g
4. Khóc bé hoặc không khóc được Không □ Có □
5. Da, môi không hồng Không □ Có □
6. Bú kém hoặc bỏ bú Không □ Có □
7. Tuổi thai < 34 tuần Không □ Có o
8. Suy giảm miễn dịch chưa xác định mức độ hoặc mức độ nặng, có biểu hiện lâm
sàng nghi nhiễm HIV Không □ Có □
9. Các chống chỉ định khác, nếu có ghi rõ:
…………………………………………………………………………………
Không □ Có □
II. Kết luận:
- Đủ điều kiện tiêm chủng ngay (Tất cả đều KHÔNG có điểm bất thường) □
Loại vắc xin tiêm chủng lần này: …………………………………………………………….
- Chống chỉ định tiêm chủng (Khi CÓ điểm bất thường tại mục 9) □
- Tạm hoãn tiêm chủng (Khi CÓ bất kỳ một điểm bất thường tại các mục 1,2,3,4,5,6,7,8) □
- Đề nghị khám sàng lọc tại bệnh viện: Không □ Có □
+ Lý do: ......................................................................................................................
…....giờ …….phút, ngày....tháng....năm…..
Người thực hiện sàng lọc
(ký, ghi rõ họ và tên)
PHỤ LỤC III
(Ban hành kèm theo Quyết định số 1575/QĐ-BYT ngày 27 tháng 03 năm 2023)
16:49 27/10/26 about:blank
about:blank 11/17
BỆNH VIỆN
……………….……..
CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
Độc lập - Tự do - Hạnh phúc
BẢNG KIỂM TRƯỚC TIÊM CHỦNG ĐỐI VỚI ĐỐI TƯỢNG TỪ 1 THÁNG TUỔI TRỞ LÊN TẠI
CÁC CƠ SỞ TIÊM CHỦNG THUỘC BỆNH VIỆN
Họ và tên trẻ: ………………………………………………………………………..Nam □ Nữ □
Tuổi:........................................ sinh ngày ……………tháng ………….năm .....................
Địa chỉ: .......................................................................................................................
Họ tên bố/mẹ: ……………………………………………. Điện thoại:....................................
Cân nặng: , kg Thân nhiệt: , °C
I. Khám sàng lọc:
1. Phản ứng phản vệ mức độ III trở lên sau lần tiêm chủng trước Không □ Có □
2. Đang mắc bệnh cấp tính hoặc bệnh mạn tính tiến triển* Không □ Có □
3. Đang hoặc mới kết thúc đợt điều trị corticoid liều cao (tương đương prednison
>2mg/kg/ngày), hóa trị, xạ trị, gammaglobulin** Không □ Có □
4. Sốt/Hạ thân nhiệt (Sốt: nhiệt độ ≥ 38°C; Hạ thân nhiệt: nhiệt độ ≤ 35,5°C) Không □ Có □
5. Suy giảm miễn dịch chưa xác định mức độ hoặc mức độ nặng, có biểu hiện lâm
sàng nghi nhiễm HIV Không □ Có □
6. Nghe tim bất thường*** Không □ Có □
7. Nhịp thở, nghe phổi bất thường*** Không □ Có □
8. Tri giác bất thường (li bì hoặc kích thích) Không □ Có □
9. Các chống chỉ định khác, nếu có ghi rõ:
……………………………………………………………………………………..
Không □ Có □
*: Chỉ định tiêm vắc xin nếu trẻ có bệnh nhẹ (ho, sổ mũi, tiêu chảy mức độ nhẹ….. và không sốt), bú tốt, ăn
tốt
**: Trừ kháng huyết thanh viêm gan B
***: Nếu khám chuyên khoa không cần xử trí cấp cứu thì chỉ định tiêm chủng
- Khám sàng lọc theo chuyên khoa: Không □ Có □, chuyên khoa: ……………………
+ Lý do: ......................................................................................................................
+ Kết quả: ...................................................................................................................
+ Kết luận: ..................................................................................................................
II. Kết luận:
- Đủ điều kiện tiêm chủng ngay (Tất cả đều KHÔNG có điểm bất thường) □
16:49 27/10/26 about:blank
about:blank 12/17
Loại vắc xin tiêm chủng lần này: …………………………………………………………..
- Chống chỉ định tiêm chủng (Khi CÓ điểm bất thường tại mục 1,9) □
- Tạm hoãn tiêm chủng (Khi CÓ bất kỳ một điểm bất thường tại các mục 2,3,4,5,6,7,8) □
…....giờ …….phút, ngày....tháng....năm…..
Người thực hiện sàng lọc
(ký, ghi rõ họ và tên)
PHỤ LỤC IV
(Ban hành kèm theo Quyết định số 1575/QĐ-BYT ngày 27 tháng 03 năm 2023)
BỆNH VIỆN
……………….……..
CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
Độc lập - Tự do - Hạnh phúc
BẢNG KIỂM TRƯỚC TIÊM CHỦNG ĐỐI VỚI TRẺ DƯỚI 1 THÁNG TUỔI TẠI CÁC CƠ SỞ
TIÊM CHỦNG THUỘC BỆNH VIỆN
Họ và tên trẻ:………………………………………………………………………. Nam □ Nữ □
Sinh: ……….. giờ …….. ngày…….. tháng …… năm ……… Tuổi thai khi sinh: ................
Địa chỉ: .......................................................................................................................
Họ tên bố/mẹ: …………………………………………….. Điện thoại: ..................................
Cân nặng: g Thân nhiệt: , °C
Mẹ đã xét nghiệm HbsAg: Không □ Có □ Kết quả: Dương tính □ Âm tính □
I. Khám sàng lọc:
Các dấu hiệu hiện tại:
1. Tình trạng sức khỏe chưa ổn định Không □ Có □
2. Sốt/Hạ thân nhiệt (Sốt: nhiệt độ ≥ 38°C; Hạ thân nhiệt: nhiệt độ ≤ 35,5°C ) Không □ Có □
3. Khóc bé hoặc không khóc Không □ Có □
4. Da, môi không hồng Không □ Có □
5. Bú kém hoặc bỏ bú Không □ Có □
6. Tuổi thai < 28 tuần Không □ Có □
7. Tuổi thai < 34 tuần* Không □ Có □
8. Suy giảm miễn dịch chưa xác định mức độ hoặc mức độ nặng, có biểu hiện lâm
sàng nghi nhiễm HIV* Không □ Có □
9. Các chống chỉ định khác, nếu có ghi rõ
……………………………………………………………………………
Không □ Có □
* Chỉ áp dụng với vắc xin phòng lao (BCG)
16:49 27/10/26 about:blank
about:blank 13/17
- Khám sàng lọc theo chuyên khoa: Không □ Có □, chuyên khoa: ……………………
+ Lý do: ......................................................................................................................
+ Kết quả: ...................................................................................................................
+ Kết luận: ..................................................................................................................
II. Kết luận:
- Đủ điều kiện tiêm chủng ngay (Tất cả đều KHÔNG có điểm bất thường) □
Loại vắc xin tiêm chủng lần này: …………………………………………………………..
- Chống chỉ định tiêm chủng (Khi CÓ điểm bất thường tại mục 9) □
- Tạm hoãn tiêm chủng (Khi CÓ bất kỳ một điểm bất thường tại các mục 1,2,3,4,5,6,7,8) □
…....giờ …….phút, ngày....tháng....năm…..
Người thực hiện sàng lọc
(ký, ghi rõ họ và tên)
PHỤ LỤC V
(Ban hành kèm theo Quyết định số 1575/QĐ-BYT ngày 27 tháng 03 năm 2023)
TẦN SỐ THỞ BÌNH THƯỜNG LÚC NGHỈ Ở TRẺ THEO CÁC NHÓM TUỔI
Tuổi (năm) Nhịp thở (tần số thở theo phút)
Sơ sinh 40 - 50
< 1 30 - 40
1 - 2 25 - 35
2 - 5 25 - 30
5 - 12 20 - 25
> 12 15 - 20
(Hướng dẫn điều trị - Tập III - Xử trí cấp cứu nhi khoa)
PHỤ LỤC VI
(Ban hành kèm theo Quyết định số 1575/QĐ-BYT ngày 27 tháng 03 năm 2023)
NHỊP TIM BÌNH THƯỜNG THEO TUỔI
Tuổi (năm) Nhịp tim (tần số tim/phút)
Sơ sinh 140 - 160
< 1 110 - 160
1 - 2 100 - 150
2 - 5 95 - 140
5 - 12 80 - 120
16:49 27/10/26 about:blank
about:blank 14/17
>12 60 - 100
(Hướng dẫn điều trị - Tập III - Xử trí cấp cứu nhi khoa)
PHỤ LỤC VII
(Ban hành kèm theo Quyết định số 1575/QĐ-BYT ngày 27 tháng 03 năm 2023)
CHỐNG CHỈ ĐỊNH, TẠM HOÃN TIÊM CHỦNG ĐỐI VỚI TRẺ EM MẮC SUY GIẢM MIỄN
DỊCH BẨM SINH
1. Chống chỉ định, tạm hoãn tiêm chủng đối với trẻ em mắc suy giảm miễn dịch (SGMD) bẩm sinh
Phân loại Thể bệnh SGMD bẩm sinh Chống chỉ định Ghi chú
Suy giảm dòng
Tế bào T
- SGMD kết hợp mức độ
nặng.
- Hội chứng Wiskott- Aldrich
- Hội chứng tăng IgM
- Tất cả vắc xin sống
giảm độc lực
- Trẻ em trong gia đình có người
mắc SGMD kết hợp mức độ nặng
chưa được xét nghiệm loại trừ
bệnh: tạm hoãn tiêm chủng vắc
xin Rota, OPV
Suy giảm dòng
tế bào B
- SGMD biến thiên phổ biến
(CVID)
- Suy giảm miễn dịch không
có Gammaglobulin
- Vắc xin sốt vàng
- Vắc xin bại liệt uống
(OPV)
- Vắc xin varicella Zoster
(VZV)
- Trẻ có thể tiêm chủng các loại
vắc xin: DTP, Hib, IPV, viêm
màng não mô cầu, MMR, IPV, vắc
xin cúm bất hoạt. Vắc xin phế cầu
cộng hợp để tiêm liều cơ bản, vắc
xin polysaccharide để tiêm nhắc.
- Thận trọng: với vắc xin phòng
lao (BCG)
Suy giảm miễn
dịch dòng bổ thể
- Thiếu hụt bẩm sinh bổ thể
C2, C3, C4, C8, C9
- Các loại vắc xin có thể tiêm nhắc
cho trẻ: vắc xin Hib, phế cầu, não
mô cầu.
Suy giảm miễn
dịch dòng thực
bào
- Bệnh u hạt bẩm sinh
(CGD)
- Bất thường bám dính bạch
cầu (LAD)
- Vắc xin phòng lao
(BCG)
- Vắc xin Salmonella
typhi sống
- Có thể tiêm chủng tất cả các vắc
xin khác.
(Theo Tổ chức Quốc tế về Suy giảm miễn dịch bẩm sinh - IPOPI 2013)
2. Trường hợp ghép tủy: Tùy thuộc tình trạng miễn dịch sau ghép để chỉ định tiêm chủng
3. Lưu ý cho người thân trong gia đình bệnh nhân SGMD bẩm sinh
Những người thân sống cùng trong gia đình của người bệnh nên được tiêm phòng các loại vắc xin để tránh
nguy cơ nhiễm bệnh và lây cho người bệnh SGMD bẩm sinh. Tuy nhiên, cần lưu ý:
- Tránh sử dụng vắc xin sống giảm độc lực (trừ vắc xin phòng bệnh sởi-quai bị-rubella (MMR) và vắc xin
phòng lao (BCG)) cho những người tiếp xúc gần với bệnh nhân SGMD bẩm sinh thể nặng (như thể: SGMD
kết hợp mức độ nặng).
- Vắc xin bại liệt: chỉ định tiêm chủng vắc xin bại liệt bất hoạt dạng tiêm (IPV) cho người thân của bệnh
nhân thay cho vắc xin bại liệt dạng uống (OPV).
16:49 27/10/26 about:blank
about:blank 15/17
- Bệnh nhân SGMD bẩm sinh không tiếp xúc với người mới được uống vắc xin bOPV trong 24 giờ đầu tiên
sau khi tiêm và tránh tiếp xúc gần gũi trong khoảng 4-6 tuần sau đó.
PHỤ LỤC VIII
(Ban hành kèm theo Quyết định số 1575/QĐ-BYT ngày 27 tháng 03 năm 2023)
PHÂN LOẠI MỨC ĐỘ MIỄN DỊCH Ở TRẺ NHIỄM HIV
Mức độ suy giảm
miễn dịch
Tỷ lệ % tế bào CD4 (hoặc số lượng tế bào CD4/mm3)
≤ 11 tháng 12- 35 tháng 36 - 59 tháng ≥ 5 tuổi
Không suy giảm >35 % >30 % >25 % > 500 tế bào/mm3
Suy giảm nhẹ 30-35 % 25-30 % 20-25 % 350 - 499 TB/mm3
Suy giảm tiến triển 25-29 % 20-24 % 15-19% 200 - 349 TB/mm3
Suy giảm nặng <25 % hoặc<1500 TB/mm3 <20% hoặc<750 TB/ mm3 <15 %<350 TB/mm3 <15% hoặc< 200 TB/mm3
(Theo Hướng dẫn Điều trị và chăm sóc HIV/AIDS, Bộ Y tế)
Lưu ý: Bệnh HIV tiến triển:
- Đối với người lớn và trẻ nhiễm HIV ≥ 5 tuổi: khi CD4 < 200 tế bào/mm3 hoặc người bệnh ở giai đoạn lâm
sàng 3 hoặc 4.
- Đối với trẻ nhiễm HIV < 5 tuổi: tất cả các trường hợp này được coi là bệnh HIV tiến triển.
PHỤ LỤC IX
(Ban hành kèm theo Quyết định số 1575/QĐ-BYT ngày 27 tháng 03 năm 2023)
CHỈ ĐỊNH, TẠM HOÃN, THẬN TRỌNG TIÊM CHỦNG MỘT SỐ LOẠI VẮC XIN ĐỐI VỚI TRẺ
PHƠI NHIỄM VỚI HIV, NHIỄM HIV
Loại vắc xin Chỉ định Tạm hoãn, thận trọng
Vắc xin phòng lao
(BCG)
- Phơi nhiễm với HIV nhưng
chưa có triệu chứng lâm sàng
- Trẻ được chẩn đoán xác định
nhiễm HIV được điều trị ARV
có lâm sàng và tình trạng miễn
dịch ổn định (CD4 > 25% với trẻ
< 5 tuổi)
Tạm hoãn:
- Trẻ có triệu chứng lâm sàng nghi nhiễm HIV tạm
hoãn cho đến khi khẳng định tình trạng nhiễm HIV
- Trẻ được chẩn đoán xác định nhiễm HIV nhưng
chưa được điều trị ARV. Tiêm chủng khi trẻ được
điều trị ARV có lâm sàng và tình trạng miễn dịch ổn
định (CD4 > 25% với trẻ < 5 tuổi)
- Trẻ được chẩn đoán xác định nhiễm HIV được điều
trị ARV nhưng tình trạng miễn dịch chưa ổn định
(CD4 ≤ 25% ở trẻ < 5 tuổi).
Vắc xin bại liệt sống,
giảm độc lực dạng
uống (OPV)
- Trẻ nhiễm HIV không có triệu
chứng lâm sàng
Tạm hoãn:
16:49 27/10/26 about:blank
about:blank 16/17
- Trẻ nhiễm HIV có lâm sàng và
tình trạng miễn dịch ổn định
Trẻ chẩn đoán xác định nhiễm HIV có triệu chứng
lâm sàng hoặc tình trạng miễn dịch chưa ổn định
(CD4<15% hoặc <750 với trẻ <12 tháng; <500 với
trẻ 1-5 tuổi; <200 trẻ ≥6 tuổi).
Vắc xin phòng tiêu
chảy cấp do Rota vi
rút
Trẻ phơi nhiễm với HIV và trẻ
nhiễm HIV không có tình trạng
suy giảm miễn dịch nặng.
Tạm hoãn:
Trẻ chẩn đoán xác định nhiễm HIV có suy giảm
miễn dịch mức độ nặng
Vắc xin phòng bệnh
sởi, rubella, quai bị
(sởi đơn, MR,
MMR)
Trẻ phơi nhiễm với HIV và trẻ
nhiễm HIV không có tình trạng
suy giảm miễn dịch mức độ
nặng
Tạm hoãn:
Trẻ chẩn đoán xác định nhiễm HIV suy giảm miễn
dịch mức độ nặng.
Các vắc xin khác
không phải là vắc
xin sống
Chỉ định tiêm chủng như mọi trẻ
không nhiễm HIV khác.
(Theo Khuyến nghị của WHO về lịch tiêm chủng các vắc xin - tháng 11/2021)
16:49 27/10/26 about:blank
about:blank 17/17
